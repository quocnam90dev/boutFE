// Tuples
let arr = ['ryu', 25, true]
arr[0] = false
arr[1] = 'yoshi'
arr = [30, false, 'yoshi']

let tup: [string, number, boolean] = ['ryu', 25, true]
tup[0] = 'ken'
tup[1] = 30

// let student: [string, number]
// student = [23123, 'awdaw']
// student = ['chun-li', 223231]

// arrays
let names = ['luigi', 'mario', 'yoshi']

// names = 'jelly'
names.push('toad')
// names.push(3)
// names[0] = 2

let numbers = [10, 20, 30, 40]
numbers.push(25)
// numbers.push('shaun')
// numbers[2] = 'shaun'

let mixed = ['ken', 14, 'chun-li', 9, 19]
mixed.push('true')
mixed.push(2)
// mixed.push(false)

//objects
// this is initialized object so cannot change props or add more props inside
let ninja = {
  name: 'mario',
  belt: 'black',
  age: 30
}
ninja.age = 50
ninja.name = 'ryyu'
// ninja.age = '30'
// ninja.skills = ['fighting', 'sneaking']

// ninja = {
//   name: '45',
//   belt: 'orange',
//   age: 40,
//   skills: []
// }